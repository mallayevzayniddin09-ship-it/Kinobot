import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from aiogram.dispatcher.filters import CommandStart
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.dispatcher.handler import CancelHandler
import asyncio
import os

API_TOKEN = '7805028417:AAHK9C4QwNnBSImdOI-B77MZ_ZJdrAcSMWM'
CHANNEL_ID = '@fcmobile_uz_savdo'
ADMIN_ID = 6857712473

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)
logging.basicConfig(level=logging.INFO)

# Obuna tekshiruvchi middleware
class CheckSubscriptionMiddleware(BaseMiddleware):
    async def on_pre_process_message(self, message: types.Message, data: dict):
        user = message.from_user.id
        try:
            chat_member = await bot.get_chat_member(CHANNEL_ID, user)
            if chat_member.status not in ["member", "creator", "administrator"]:
                markup = InlineKeyboardMarkup()
                markup.add(InlineKeyboardButton("📢 Kanalga obuna bo'lish", url=f"https://t.me/{CHANNEL_ID[1:]}"))
                await message.answer("Botdan foydalanish uchun kanalga obuna bo‘ling:", reply_markup=markup)
                raise CancelHandler()
        except:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("📢 Kanalga obuna bo'lish", url=f"https://t.me/{CHANNEL_ID[1:]}"))
            await message.answer("Botdan foydalanish uchun kanalga obuna bo‘ling:", reply_markup=markup)
            raise CancelHandler()

dp.middleware.setup(CheckSubscriptionMiddleware())

@dp.message_handler(commands=["start"])
async def start_handler(message: types.Message):
    await message.answer("🎬 Assalomu alaykum!\nBotdan foydalanish uchun kod yuboring. Masalan: 1")

@dp.message_handler(lambda message: not message.text.isdigit())
async def only_digits(message: types.Message):
    await message.reply("❗️Faqat raqam yuboring. Masalan: 1")

@dp.message_handler()
async def handle_code(message: types.Message):
    code = message.text
    user_id = message.from_user.id

    if user_id == ADMIN_ID:
        await message.reply("✅ Admin tasdiqlandi. Siz kino yuklashingiz mumkin.")
        return

    if code == "1":
        await message.reply_video("https://t.me/kinodunyo_uzb/4", caption="🎥 Kod 1 uchun kino")
    else:
        await message.reply("❌ Bu kodga mos kino topilmadi.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)