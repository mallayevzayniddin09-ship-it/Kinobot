
# KinoBot

Telegram bot that sends movies based on a code (1, 2, 3...) only after checking channel subscription.

## Admin Features
- Admin can send codes (like "1") and get back movie links
- Users must join the required channel to get access

## Deployment
Designed to run on Railway using `.env` and `Procfile`.
