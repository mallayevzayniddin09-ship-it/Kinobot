
import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
from aiogram.dispatcher.filters import Command
from dotenv import load_dotenv

load_dotenv()

API_TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

codes = {
    "1": "https://t.me/example1",
    "2": "https://t.me/example2",
    "3": "https://t.me/example3"
}

async def check_subscription(user_id):
    try:
        member = await bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status in ["member", "creator", "administrator"]
    except:
        return False

@dp.message_handler(commands=["start"])
async def start(message: Message):
    if not await check_subscription(message.from_user.id):
        await message.answer("❗ Botdan foydalanish uchun @fcmobile_uz_savdo kanaliga obuna bo‘ling.")
    else:
        await message.answer("✅ Raqamni yuboring. Masalan: 1")

@dp.message_handler(lambda message: message.text.isdigit())
async def handle_code(message: Message):
    if not await check_subscription(message.from_user.id):
        await message.answer("❗ Botdan foydalanish uchun avval kanalga obuna bo‘ling: @fcmobile_uz_savdo")
        return

    code = message.text.strip()
    if str(message.from_user.id) == str(ADMIN_ID) and code in codes:
        await message.answer(f"🎬 Kino: {codes[code]}")
    else:
        await message.answer("❗ Noto‘g‘ri raqam yoki sizda ruxsat yo‘q.")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
